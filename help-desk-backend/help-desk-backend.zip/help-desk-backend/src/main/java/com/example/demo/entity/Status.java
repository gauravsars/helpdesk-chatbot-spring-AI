package com.example.demo.entity;

public enum Status {

    OPEN,RESOLVED,CLOSED
}
